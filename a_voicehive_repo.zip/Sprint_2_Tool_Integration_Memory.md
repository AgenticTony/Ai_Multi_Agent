# Sprint 2 – Tool Integration & Memory

**Duration**: 2 weeks  
**Goal**: Integrate lead tools (CRM, calendar, SMS/email) and implement memory using Mem0.

---

## ✅ Step-by-Step Tasks

### 1. Build Tool Interfaces
- [ ] Create `tools/crm.py` for storing lead name, phone, issue
- [ ] Create `tools/calendar.py` for booking and checking availability
- [ ] Create `tools/notify.py` to send SMS/email confirmation using Twilio/SMTP

### 2. Integrate Tools into Agent
- [ ] In `agent_roxy.py`, import tool functions
- [ ] Add conditional logic: based on user intent, call relevant tool
- [ ] Use ADK-style function calling to simulate "tool use" chain

### 3. Setup Mem0 for Real-Time Memory
- [ ] Subscribe to Mem0 Pro plan
- [ ] Create memory schema: session ID, call ID, user name, query, answer, tags
- [ ] Connect via API key (store in Secret Manager)
- [ ] Implement basic memory read/write in `memory/mem0.py`

### 4. Store Lead Data
- [ ] After each successful call, store:
  - User name
  - Phone number
  - Call intent
  - Booking time
  - Transcript summary

### 5. Simulate Real Call Workflows
- [ ] Run 5 mock call flows:
  - New appointment booking
  - Rescheduling
  - Cancellation
  - Objection response
  - FAQ fallback
- [ ] Verify data is stored and retrievable from Mem0

---

## 📦 Deliverables
- Working integrations: CRM, calendar, SMS/email
- Functional memory layer via Mem0
- Lead storage and retrieval
- Five test calls with data logged

## 📁 Folder Structure Example

```
/voicehive-backend/
├── agent_roxy.py
├── tools/
│   ├── crm.py
│   ├── calendar.py
│   └── notify.py
├── memory/
│   └── mem0.py
```
