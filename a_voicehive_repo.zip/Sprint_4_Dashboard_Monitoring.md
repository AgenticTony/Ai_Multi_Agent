# Sprint 4 – Dashboard & Monitoring

**Duration**: 2 weeks  
**Goal**: Create a lightweight admin dashboard and integrate monitoring/alerting on usage and system health.

---

## ✅ Step-by-Step Tasks

### 1. Set Up Dashboard UI (Next.js + Tailwind)
- [ ] Scaffold a new Next.js app
- [ ] Install Tailwind CSS
- [ ] Build key views:
  - Login screen (admin only)
  - Call logs page (name, phone, intent, timestamp)
  - Transcript viewer
  - Minutes usage tracking per client

### 2. Backend Data Sources
- [ ] Use Firebase Firestore or Realtime DB for storing logs
- [ ] Secure all endpoints via Firebase Auth
- [ ] Use serverless functions for:
  - Fetching logs
  - Filtering by agent/date/client
  - Uploading new prompt versions

### 3. Deploy to Firebase Hosting
- [ ] Connect Firebase project
- [ ] Configure build & deploy in `firebase.json`
- [ ] Enable HTTPS + custom domain (if needed)

### 4. Add Usage Metrics & Monitoring
- [ ] Cloud Logging (Stackdriver) for all backend calls
- [ ] Firestore-triggered logs for:
  - Calls exceeding 2 minutes
  - Failed bookings
- [ ] Alert rules:
  - Send Slack/email if failure rate > 5% in 24 hours
  - Notify if usage > 90% quota

---

## 📦 Deliverables
- Secure, responsive dashboard UI
- Real-time data on agent activity and call logs
- Monitoring via GCP alerts and Firestore rules
- Deployed on Firebase Hosting

## 📁 Folder Structure Example

```
/voicehive-dashboard/
├── pages/
│   ├── index.tsx
│   ├── login.tsx
│   ├── logs.tsx
│   └── usage.tsx
├── components/
│   └── Navbar.tsx
├── functions/
│   └── log_handler.ts
├── public/
├── tailwind.config.js
├── firebase.json
└── .firebaserc
```
