## 📊 Sprint 4 – Dashboard & Monitoring

### Tasks
- [ ] Build UI (logs, usage, transcripts)
- [ ] Connect Firestore + Firebase Auth
- [ ] Deploy on Firebase Hosting
- [ ] Setup GCP monitoring & alert rules

### Bugs / Concerns
- [ ] Dashboard not displaying real-time data?
- [ ] Alerts not triggering at threshold?
