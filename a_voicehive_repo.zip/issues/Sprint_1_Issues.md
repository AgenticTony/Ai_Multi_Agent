## 📞 Sprint 1 – Voice Infrastructure & Agent Core

### Tasks
- [ ] Setup Vapi.ai + Twilio phone number
- [ ] Configure OpenAI model and API key
- [ ] Implement Python ADK base agent
- [ ] Deploy backend to Cloud Run
- [ ] Connect Vapi webhook
- [ ] Verify end-to-end test call works

### Bugs / Concerns
- [ ] Audio delay observed?
- [ ] Twilio number not triggering webhook?
