## 🔧 Sprint 2 – Tool Integration & Memory

### Tasks
- [ ] Build CRM, Calendar, Notify tools
- [ ] Integrate tools into agent logic
- [ ] Setup Mem0 API connection
- [ ] Store lead session data
- [ ] Run and verify 5 mock call scenarios

### Bugs / Concerns
- [ ] Mem0 memory not persisting?
- [ ] Calendar tool not confirming slots?
