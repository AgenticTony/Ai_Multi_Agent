## 🧠 Sprint 3 – Vertex Feedback Agent

### Tasks
- [ ] Enable Vertex AI + Workbench
- [ ] Build daily transcript review agent
- [ ] Deploy and schedule Vertex pipeline
- [ ] Generate JSON feedback
- [ ] Update prompt dynamically

### Bugs / Concerns
- [ ] Pipeline not triggering daily?
- [ ] Prompt updates not loading in agent?
