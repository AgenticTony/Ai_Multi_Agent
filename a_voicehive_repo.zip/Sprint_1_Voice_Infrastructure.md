# Sprint 1 – Voice Infrastructure & Agent Core

**Duration**: 2 weeks  
**Goal**: Get the base voice agent (Roxy) live and responding to calls using Vapi.ai, GPT-4, and Python ADK.

---

## ✅ Step-by-Step Tasks

### 1. Set Up Vapi.ai + Twilio
- [ ] Create a Vapi.ai account
- [ ] Generate an API key
- [ ] Link a Twilio number (or use Vapi virtual number)
- [ ] Configure webhook to point to your Cloud Run function endpoint

### 2. Build Base Agent with Google ADK (Python)
- [ ] Install Google ADK via pip
- [ ] Create a new agent file: `agent_roxy.py`
- [ ] Define role, goals, personality, tools (e.g. CRM lookup, appointment setter)
- [ ] Handle incoming JSON payload from Vapi in a Flask/FastAPI function
- [ ] Return appropriate response: greeting, question, action confirmation

### 3. Integrate GPT via OpenAI or Vertex AI
- [ ] Choose GPT-4.1 or GPT-4o for inference (via OpenAI)
- [ ] Secure API key using Secret Manager
- [ ] Add inference call inside `agent_roxy.py`
- [ ] Token limit: ~250 tokens per turn

### 4. Deploy Backend to Google Cloud Run
- [ ] Create Dockerfile for the FastAPI or Flask app
- [ ] Build and push image to GCR
- [ ] Deploy service to Cloud Run (public HTTPS)
- [ ] Connect webhook in Vapi to this endpoint

### 5. Test End-to-End Call Flow
- [ ] Make a test call
- [ ] Ensure Roxy answers and responds clearly
- [ ] Log the conversation to console or Firestore

---

## 📦 Deliverables
- Working Roxy agent deployed on Cloud Run
- Vapi webhook responding to calls
- Agent responses powered by GPT
- Call logs printed or saved

## 📁 Folder Structure Example

```
/voicehive-backend/
├── agent_roxy.py
├── main.py
├── requirements.txt
├── Dockerfile
└── .env (not committed)
```
