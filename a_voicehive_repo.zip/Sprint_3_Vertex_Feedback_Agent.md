# Sprint 3 – Vertex Feedback Agent

**Duration**: 2 weeks  
**Goal**: Deploy a daily feedback agent using Vertex AI to improve agent prompts based on call transcripts.

---

## ✅ Step-by-Step Tasks

### 1. Setup Vertex AI Environment
- [ ] Enable Vertex AI API in your GCP project
- [ ] Create a service account with permissions for Pipelines, Storage, and Workbench
- [ ] Store credentials in Secret Manager

### 2. Build Transcript Review Agent
- [ ] Create a Vertex AI Workbench notebook
- [ ] Connect to Mem0 or transcript storage bucket
- [ ] Filter calls from the last 24 hours
- [ ] Use Gemini Pro or GPT-4 API for analysis:
  - Detect poor phrasing
  - Identify objections not handled
  - Highlight missed booking opportunities

### 3. Create Daily Feedback Pipeline
- [ ] Use Vertex Pipelines to schedule notebook daily
- [ ] Output: structured prompt feedback in JSON
- [ ] Append to `improvements/prompt_updates.json`

### 4. Prompt Versioning Logic
- [ ] Update `agent_roxy.py` to read current prompt from versioned file
- [ ] Store each prompt update with timestamp and rationale
- [ ] Rollback capability via Git or Firestore backup

### 5. Testing & Review
- [ ] Simulate a 3-day batch of call transcripts
- [ ] Run feedback loop manually
- [ ] Confirm prompt suggestions are reasonable and safe
- [ ] Push best improvement live and test agent response delta

---

## 📦 Deliverables
- Vertex Workbench notebook for call review
- Scheduled daily improvement pipeline
- Prompt version log and live update mechanism
- Simulated batch test with tracked improvements

## 📁 Folder Structure Example

```
/voicehive-backend/
├── improvements/
│   ├── prompt_updates.json
├── vertex/
│   ├── daily_feedback_pipeline.py
│   └── call_review_notebook.ipynb
```
